@extends('layouts.app')

@section('styles')
<style>
  .family-member-card { border: 1px solid rgba(148,163,184,.25); border-radius: 14px; padding: 1rem; background: var(--bg-card, #fff); }
  .family-member-card__header { display:flex; align-items:center; justify-content:space-between; gap:1rem; font-weight:800; margin-bottom:1rem; padding-bottom:.75rem; border-bottom:1px dashed rgba(148,163,184,.3); }
  .child-number { display:inline-grid; place-items:center; width:28px; height:28px; margin-left:.4rem; border-radius:50%; color:#fff; background:var(--primary); }
  .project-special-box { border:1px solid rgba(148,163,184,.25); border-radius:14px; padding:1rem; background:rgba(148,163,184,.07); }
  .theme-dark .family-member-card, .theme-dark .project-special-box { background:rgba(15,23,42,.7); border-color:rgba(255,255,255,.1); }
</style>
@endsection

@section('content')
<div class="page-header">
  <h4 class="mb-0"><i class="bi bi-person-plus text-primary"></i> إضافة مستفيد جديد</h4>
  <a href="{{ route('beneficiaries.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-right me-1"></i> رجوع</a>
</div>

@if($errors->any())
  <div class="alert alert-danger">
    <div class="fw-bold mb-1"><i class="bi bi-exclamation-triangle me-1"></i> راجع البيانات التالية:</div>
    <ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
  </div>
@endif

<div class="alert alert-warning border border-warning border-opacity-50 d-flex align-items-center justify-content-between p-3 mb-4 rounded-3 shadow-xs">
  <div class="d-flex align-items-center gap-3">
    <div class="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; min-width: 44px;">
      <i class="bi bi-file-earmark-check fs-4"></i>
    </div>
    <div>
      <h6 class="fw-bold mb-1 text-dark">مرحلة البحث المبدئي للحالات الجديدة</h6>
      <p class="mb-0 text-muted small">إذا كانت الحالة جديدة وتحتاج تقييماً وفلترة مبدئية، يمكنك تسجيلها في <strong>البحث المبدئي</strong> أولاً (في انتظار البحث - تحت البحث - تم البحث - مرفوض)، أو المتابعة هنا لتسجيل مستفيد كامل مباشرة.</p>
    </div>
  </div>
  <a href="{{ route('mobile.case-applications.index') }}" class="btn btn-warning text-dark fw-bold px-3 py-2 text-nowrap shadow-xs">
    <i class="bi bi-search me-1"></i> فتح البحث المبدئي
  </a>
</div>

<div class="card">
  <div class="card-body">
    @if(isset($changeRequest))
      <div class="alert alert-warning border border-warning shadow-sm rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-2">
        <div class="d-flex align-items-center gap-3">
          <div class="rounded-circle bg-warning text-dark d-flex align-items-center justify-content-center" style="width: 46px; height: 46px; min-width: 46px;">
            <i class="bi bi-pencil-square fs-4"></i>
          </div>
          <div>
            <h6 class="fw-bold mb-1 text-dark d-flex align-items-center gap-2">
              <span>أنت الآن تقوم بتعديل وإعادة تقديم طلب إضافة المستفيد #{{ $changeRequest->id }}</span>
              @if($changeRequest->status === 'rejected')
                <span class="badge bg-danger">مرفوض مسبقاً</span>
              @else
                <span class="badge bg-warning text-dark">معلق للمراجعة</span>
              @endif
            </h6>
            <div class="text-muted small">
              تم استرجاع وتعبئة كافة البيانات المحفوظة مسبقاً تلقائياً. يمكنك تعديل الحقول المطلوبة ثم الضغط على <strong>"حفظ وإعادة الإرسال للموافقة"</strong> دون الحاجة لإعادة إدخال أي شيء من الصفر.
            </div>
            @if($changeRequest->rejection_reason)
              <div class="mt-1 text-danger fw-bold small"><i class="bi bi-exclamation-circle-fill me-1"></i> سبب الرفض السابق: {{ $changeRequest->rejection_reason }}</div>
            @endif
          </div>
        </div>
        <a href="{{ route('change-requests.index') }}" class="btn btn-outline-dark btn-sm rounded-pill px-3">
          <i class="bi bi-x-circle me-1"></i> إلغاء والعودة لقائمة الطلبات
        </a>
      </div>
    @endif

    <form method="POST" action="{{ route('beneficiaries.store') }}">
      @csrf
      @if(isset($changeRequest))
        <input type="hidden" name="change_request_id" value="{{ $changeRequest->id }}">
      @endif

      <div class="form-section">
        <div class="form-section-title"><i class="bi bi-person-vcard"></i><span>بيانات ولي الأمر / المعيل</span></div>
        <div class="alert alert-primary py-2"><i class="bi bi-info-circle me-1"></i> الاسم الرئيسي هو اسم ولي الأمر، أما الزوج أو الزوجة والأطفال والمريض فلهم ملفات مستقلة بالأسفل.</div>
        <div class="row g-3">
          <div class="col-md-3"><label class="form-label">كود المستفيد</label><input name="code" value="{{ old('code') }}" class="form-control @error('code') is-invalid @enderror" placeholder="يُترك فارغًا للتوليد التلقائي">@error('code')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
          <div class="col-md-3"><label class="form-label form-label-required">اسم ولي الأمر بالكامل</label><input name="full_name" value="{{ old('full_name') }}" class="form-control @error('full_name') is-invalid @enderror" required placeholder="اسم ولي الأمر أو المعيل">@error('full_name')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
          <div class="col-md-3">
            <label class="form-label">الرقم القومي</label>
            <input name="national_id" id="guardian_national_id" value="{{ old('national_id') }}" class="form-control" maxlength="14" placeholder="14 رقم" oninput="checkDuplicateNationalId(this); if (typeof syncNationalIdToBirthDate === 'function') syncNationalIdToBirthDate(this.value, 'guardian_birth_date', 'guardian_age');">
            <div id="national_id_warning" class="mt-1"></div>
          </div>
          <div class="col-md-3"><label class="form-label">رقم الفيزا / كارت الكفالة</label><input name="visa_card_number" value="{{ old('visa_card_number') }}" class="form-control" placeholder="رقم كارت استلام الكفالات"></div>
          <div class="col-md-3"><label class="form-label">تاريخ الميلاد</label><input type="date" name="birth_date" id="guardian_birth_date" value="{{ old('birth_date') }}" class="form-control" oninput="calcAge(this.value, null, 'guardian_age')" onchange="calcAge(this.value, null, 'guardian_age')"></div>
          <div class="col-md-3"><label class="form-label">السن (محسوب تلقائياً)</label><input type="number" min="0" max="120" name="age" id="guardian_age" value="{{ old('age') }}" class="form-control" placeholder="تلقائي" oninput="calcBirthFromAge(this.value, 'guardian_birth_date')" onchange="calcBirthFromAge(this.value, 'guardian_birth_date')"></div>
          <div class="col-md-3"><label class="form-label">رقم الهاتف الأساسي</label><input name="phone" value="{{ old('phone') }}" class="form-control" placeholder="01xxxxxxxxx"></div>
          <div class="col-md-3"><label class="form-label">رقم هاتف إضافي</label><input name="backup_phone" value="{{ old('backup_phone') }}" class="form-control" placeholder="01xxxxxxxxx"></div>
          <div class="col-12"><label class="form-label">العنوان بالتفصيل</label><input name="address" value="{{ old('address') }}" class="form-control" placeholder="المحافظة - المركز - القرية/الشارع - العنوان التفصيلي"></div>
        </div>
      </div>

      <div class="form-section">
        <div class="form-section-title"><i class="bi bi-folder-symlink"></i><span>المشروع وحالة الملف</span></div>
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">المشروع</label>
            <select name="project_id" id="projectSelect" class="form-select">
              <option value="">— اختر المشروع —</option>
              @foreach($projects as $project)<option value="{{ $project->id }}" data-name="{{ $project->name }}" @selected((string) old('project_id') === (string) $project->id)>{{ $project->name }}</option>@endforeach
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-bold">تصنيف الحالة</label>
            <select name="classification" class="form-select">
              <option value="A" @selected(old('classification', 'A') === 'A')>تصنيف (A)</option>
              <option value="B" @selected(old('classification') === 'B')>تصنيف (B)</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">حالة الملف</label>
            <select name="status" id="statusSelect" class="form-select">
              <option value="new" @selected(old('status', 'new') === 'new')>تحت التقديم (ملف جديد)</option>
              <option value="under_review" @selected(old('status') === 'under_review')>تحت المراجعة</option>
              <option value="accepted" @selected(old('status') === 'accepted')>مقبول</option>
              <option value="rejected" @selected(old('status') === 'rejected')>مرفوض</option>
              <option value="archived_improved" @selected(old('status') === 'archived_improved')>أرشيف — تحسن مادي / شفاء</option>
              <option value="archived_deceased" @selected(old('status') === 'archived_deceased')>أرشيف — توفي</option>
            </select>
          </div>
          <div class="col-12" id="rejectionReasonBox" style="display:none"><label class="form-label text-danger">سبب الرفض</label><textarea name="rejection_reason" class="form-control" rows="2">{{ old('rejection_reason') }}</textarea></div>
          <div class="col-12" id="archiveReasonBox" style="display:none"><label class="form-label">سبب الأرشفة وتفاصيل الحالة</label><textarea name="archived_reason" class="form-control" rows="2" placeholder="تحسنت الحالة المادية، تم الشفاء، أو تفاصيل الوفاة">{{ old('archived_reason') }}</textarea></div>
        </div>

        <div id="zadProjectFields" class="project-special-box mt-4" style="display:none">
          <h6 class="fw-bold text-success mb-3"><i class="bi bi-basket2 me-1"></i> استمارة بيانات مشروع زاد (الأيتام)</h6>
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">اسم المصدر</label>
              <input name="source_name" value="{{ old('source_name') }}" class="form-control" placeholder="اسم المصدر / الجمعية / الدال">
            </div>
            <div class="col-md-4">
              <label class="form-label">رقم المسجل / رقم الدليل</label>
              <input name="reference_number" value="{{ old('reference_number') }}" class="form-control" placeholder="رقم القيد أو الدليل">
            </div>
            <div class="col-md-4">
              <label class="form-label">اسم الزوج المتوفي</label>
              <input name="deceased_husband_name" value="{{ old('deceased_husband_name') }}" class="form-control" placeholder="اسم الزوج المتوفي رباعياً">
            </div>
            <div class="col-md-4">
              <label class="form-label">عدد الأولاد (ممنوع لطفل واحد)</label>
              <select name="children_count" class="form-select">
                <option value="">— اختر عدد الأولاد —</option>
                <option value="2" @selected(old('children_count') == '2')>2 أولاد</option>
                <option value="3" @selected(old('children_count') == '3')>3 أولاد</option>
                <option value="4" @selected(old('children_count') == '4')>4 أولاد</option>
                <option value="5" @selected(old('children_count') == '5')>5 أولاد</option>
                <option value="غير ذلك" @selected(old('children_count') == 'غير ذلك')>غير ذلك (أكثر من 5)</option>
              </select>
            </div>
            <div class="col-md-8">
              <label class="form-label">العنوان والمواصلات ( البلد / موقف إيه / بيتركب ليها إيه )</label>
              <input name="transit_details" value="{{ old('transit_details') }}" class="form-control" placeholder="الموقف والمواصلات للوصول للقرية أو المنزل بالتفصيل">
            </div>
            <div class="col-12">
              <label class="form-label">متوفى من امتى / كان شغال إيه / سبب الوفاة</label>
              <textarea name="death_details" class="form-control" rows="2" placeholder="تاريخ أو مدة الوفاة، مهنة الزوج قبل الوفاة، سبب الوفاة...">{{ old('death_details') }}</textarea>
            </div>
            <div class="col-12">
              <label class="form-label">الدخل والمعاشات (تكافل / تأمين / مساعدات جمعيات / أهلها / أهل زوجها / جيران / مساجد)</label>
              <textarea name="income_aid_sources" class="form-control" rows="2" placeholder="تفاصيل المعاشات والمساعدات المالية ومصادر الدخل...">{{ old('income_aid_sources') }}</textarea>
            </div>
            <div class="col-12">
              <label class="form-label">الحالة الاجتماعية للأم والمصاريف (كهرباء، غاز، مياه، إيجار، ديون، العجز)</label>
              <textarea name="expenses_debts_details" class="form-control" rows="2" placeholder="الحالة الاجتماعية، فواتير الخدمات، قيمة الإيجار، الديون، وأوجه العجز...">{{ old('expenses_debts_details') }}</textarea>
            </div>
          </div>
        </div>

        <div id="bathaFields" class="project-special-box mt-4" style="display:none">
          <h6 class="fw-bold text-primary mb-3"><i class="bi bi-hospital me-1"></i> ملف المريض — مشروع بعثاء الأمل</h6>
          <div class="row g-3">
            <div class="col-md-4"><label class="form-label">اسم المريض بالكامل</label><input name="patient_name" id="patient_name" value="{{ old('patient_name') }}" class="form-control" placeholder="مختلف عن اسم ولي الأمر"></div>
            <div class="col-md-2"><label class="form-label">صلة المريض</label><select name="patient_relationship" id="patient_relationship" class="form-select" onchange="syncPatientFromBeneficiary()"><option value="husband" @selected(old('patient_relationship') === 'husband')>الزوج</option><option value="wife" @selected(old('patient_relationship') === 'wife')>الزوجة</option><option value="child" @selected(old('patient_relationship') === 'child')>ابن / طفلة</option><option value="patient" @selected(old('patient_relationship', 'patient') === 'patient')>المستفيد نفسه</option><option value="other" @selected(old('patient_relationship') === 'other')>فرد آخر</option></select></div>
            <div class="col-md-2"><label class="form-label">تاريخ الميلاد</label><input name="patient_birth_date" id="patient_birth_date" type="date" value="{{ old('patient_birth_date') }}" class="form-control" oninput="calcAge(this.value, null, 'patient_age')" onchange="calcAge(this.value, null, 'patient_age')"></div>
            <div class="col-md-2"><label class="form-label">السن (محسوب تلقائياً)</label><input name="patient_age" id="patient_age" type="number" min="0" max="120" value="{{ old('patient_age') }}" class="form-control" placeholder="تلقائي" oninput="calcBirthFromAge(this.value, 'patient_birth_date')" onchange="calcBirthFromAge(this.value, 'patient_birth_date')"></div>
            <div class="col-md-2"><label class="form-label">كود المريض</label><input name="patient_code" id="patient_code" value="{{ old('patient_code') }}" class="form-control" placeholder="تلقائي"></div>
            <div class="col-md-3"><label class="form-label">هاتف المريض</label><input name="patient_phone" id="patient_phone" value="{{ old('patient_phone') }}" class="form-control" placeholder="01xxxxxxxxx"></div>
            <div class="col-md-3"><label class="form-label">هاتف إضافي</label><input name="patient_backup_phone" id="patient_backup_phone" value="{{ old('patient_backup_phone') }}" class="form-control" placeholder="01xxxxxxxxx"></div>
            <div class="col-md-3"><label class="form-label">نوع المساعدة</label><select name="sponsorship_scope_type" class="form-select"><option value="kafala" @selected(old('sponsorship_scope_type') === 'kafala')>كفالة شهرية</option><option value="temporary" @selected(old('sponsorship_scope_type') === 'temporary')>مساعدة مؤقتة / عملية / علاج</option></select></div>
            <div class="col-md-3"><label class="form-label">مبلغ الكفالة / المساعدة</label><input name="monthly_sponsorship_amount" type="number" min="0" step="0.01" value="{{ old('monthly_sponsorship_amount') }}" class="form-control"></div>
            <div class="col-md-3"><label class="form-label">عدد إخوته</label><input name="brothers_count" type="number" min="0" value="{{ old('brothers_count') }}" class="form-control"></div>
            <div class="col-md-3"><label class="form-label">عدد أبنائه إن كان كبيرًا</label><input name="adult_children_count" type="number" min="0" value="{{ old('adult_children_count') }}" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">أعمار الأبناء وتفاصيلهم</label><input name="adult_children_ages" value="{{ old('adult_children_ages') }}" class="form-control" placeholder="مثال: 12، 15، 18 سنة"></div>
            <div class="col-12"><label class="form-label">تفاصيل الحالة والتقارير والورق</label><textarea name="notes_cases" class="form-control" rows="3" placeholder="التشخيص، العملية المطلوبة، التقارير الطبية والمستندات...">{{ old('notes_cases') }}</textarea></div>
          </div>
        </div>

        <div id="midrarProjectFields" class="project-special-box mt-4" style="display:none">
          <h6 class="fw-bold text-info-emphasis mb-3"><i class="bi bi-droplet-half me-1"></i> بيانات مشروع مدرار (وصلات مياه - أسقف - صدقات جارية)</h6>
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">نوع الاحتياج</label>
              <select name="need_type" class="form-select">
                <option value="وصله مياه" @selected(old('need_type') == 'وصله مياه')>وصلة مياه</option>
                <option value="سقف" @selected(old('need_type') == 'سقف')>سقف</option>
                <option value="اخري" @selected(old('need_type') == 'اخري')>أخرى</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">عدد أفراد الأسرة</label>
              <input name="family_members_count" type="number" min="1" max="30" value="{{ old('family_members_count') }}" class="form-control" placeholder="إجمالي المقيمين">
            </div>
            <div class="col-md-4">
              <label class="form-label">اسم الدليل</label>
              <input name="guide_name" value="{{ old('guide_name') }}" class="form-control" placeholder="اسم الدليل بالقرية">
            </div>
            <div class="col-md-4">
              <label class="form-label">رقم تليفون الدليل</label>
              <input name="guide_phone" value="{{ old('guide_phone') }}" class="form-control" placeholder="01xxxxxxxxx">
            </div>
            <div class="col-12">
              <label class="form-label">وصف الحالة الاجتماعية والسكن</label>
              <textarea name="social_status_description" class="form-control" rows="2" placeholder="وصف حالة الأسرة والسكن والاحتياج...">{{ old('social_status_description') }}</textarea>
            </div>
          </div>
        </div>
      </div>

      @include('beneficiaries._family_members_fields')

      <div class="form-section">
        <div class="form-section-title"><i class="bi bi-hand-thumbs-up"></i><span>نوع المساعدة وآلية التحصيل</span></div>
        <div class="row g-3">
          <div class="col-md-4"><label class="form-label form-label-required">نوع المساعدة</label><select name="assistance_type" id="assistanceType" class="form-select" required><option value="monthly" @selected(old('assistance_type', 'monthly') === 'monthly')>كفالة شهرية</option><option value="one_time" @selected(old('assistance_type') === 'one_time')>مساعدة مؤقتة / مرة واحدة</option><option value="in_kind" @selected(old('assistance_type') === 'in_kind')>مساعدة عينية</option><option value="service" @selected(old('assistance_type') === 'service')>مساعدة خدمية / علاجية</option><option value="financial" @selected(old('assistance_type') === 'financial')>مساعدة مالية</option></select></div>
          <div class="col-md-4 monthly-fields"><label class="form-label">يوم استلام الكفالة</label><input name="collection_day" type="number" min="1" max="31" value="{{ old('collection_day') }}" class="form-control" placeholder="1 إلى 31"></div>
          <div class="col-md-4 monthly-fields"><label class="form-label">طريقة الاستلام</label><select name="collection_method" class="form-select"><option value="فيزا" @selected(old('collection_method') === 'فيزا')>فيزا</option><option value="باب البيت" @selected(old('collection_method') === 'باب البيت')>باب البيت</option><option value="مقر المؤسسة" @selected(old('collection_method') === 'مقر المؤسسة')>مقر المؤسسة</option><option value="شحن عيني" @selected(old('collection_method') === 'شحن عيني')>شحن عيني</option></select></div>
        </div>
      </div>

      <div class="form-section"><div class="form-section-title"><i class="bi bi-pencil-square"></i><span>ملاحظات عامة</span></div><textarea name="notes" class="form-control" rows="3" placeholder="ملاحظات داخلية حول الأسرة والحالة">{{ old('notes') }}</textarea></div>

      <div class="d-flex gap-2 justify-content-end mt-4">
        <a href="{{ route('beneficiaries.index') }}" class="btn btn-outline-secondary"><i class="bi bi-x-lg me-1"></i> إلغاء</a>
        @if(isset($changeRequest))
          @if(auth()->user()?->hasRole(['admin', 'super_admin']))
            <button type="submit" name="approve_now" value="1" class="btn btn-success px-4 fw-bold shadow-sm">
              <i class="bi bi-check-circle-fill me-1"></i> حفظ وموافقة فورية
            </button>
          @endif
          <button type="submit" class="btn btn-warning text-dark px-4 fw-bold shadow-sm">
            <i class="bi bi-send-check-fill me-1"></i> حفظ وتحديث الطلب وإعادة الإرسال للموافقة
          </button>
        @else
          <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="bi bi-check-lg me-1"></i> حفظ المستفيد وملفات الأسرة</button>
        @endif
      </div>
    </form>
  </div>
</div>
@endsection

@section('scripts')
<script>
function syncPatientFromBeneficiary() {
  const rel = document.getElementById('patient_relationship')?.value;
  if (rel === 'patient') {
    const mainName = document.querySelector('input[name="full_name"]')?.value;
    const pName = document.getElementById('patient_name');
    if (pName && (!pName.value || pName.value === mainName)) {
      pName.value = mainName || '';
    }
    const bDate = document.getElementById('guardian_birth_date')?.value;
    const pDate = document.getElementById('patient_birth_date');
    if (bDate && pDate && !pDate.value) {
      pDate.value = bDate;
      if (typeof calcAge === 'function') calcAge(bDate, null, 'patient_age');
    }
    const bAge = document.getElementById('guardian_age')?.value;
    const pAge = document.getElementById('patient_age');
    if (bAge && pAge && !pAge.value) {
      pAge.value = bAge;
    }
    const phone = document.querySelector('input[name="phone"]')?.value;
    const pPhone = document.getElementById('patient_phone');
    if (phone && pPhone && !pPhone.value) {
      pPhone.value = phone;
    }
    const bPhone = document.querySelector('input[name="backup_phone"]')?.value;
    const pBPhone = document.getElementById('patient_backup_phone');
    if (bPhone && pBPhone && !pBPhone.value) {
      pBPhone.value = bPhone;
    }
  }
}

document.addEventListener('DOMContentLoaded', function () {
  const assistanceType = document.getElementById('assistanceType');
  const projectSelect = document.getElementById('projectSelect');
  const statusSelect = document.getElementById('statusSelect');
  function toggleMonthlyFields() { const monthly = assistanceType?.value === 'monthly'; document.querySelectorAll('.monthly-fields').forEach(el => el.style.display = monthly ? '' : 'none'); }
  function toggleProjectFields() {
    const option = projectSelect?.options[projectSelect.selectedIndex];
    const name = option?.dataset.name || option?.text || '';
    const zadBox = document.getElementById('zadProjectFields');
    const bathaBox = document.getElementById('bathaFields');
    const midrarBox = document.getElementById('midrarProjectFields');
    const isZad = name.includes('زاد');
    const isBatha = name.includes('بعثاء') || name.includes('بناء') || name.includes('الأمل') || name.includes('علاج') || name.includes('أورام');
    const isMidrar = name.includes('مدرار') || name.includes('مياه') || name.includes('سقف');
    zadBox.style.display = isZad ? '' : 'none';
    bathaBox.style.display = isBatha ? '' : 'none';
    midrarBox.style.display = isMidrar ? '' : 'none';
    zadBox.querySelectorAll('input,select,textarea').forEach(field => field.disabled = !isZad);
    bathaBox.querySelectorAll('input,select,textarea').forEach(field => field.disabled = !isBatha);
    midrarBox.querySelectorAll('input,select,textarea').forEach(field => field.disabled = !isMidrar);
    if (typeof toggleSpouseZadMode === 'function') toggleSpouseZadMode(isZad);
  }
  function toggleStatusReason() { const status = statusSelect?.value; const rejectionBox = document.getElementById('rejectionReasonBox'); const archiveBox = document.getElementById('archiveReasonBox'); rejectionBox.style.display = status === 'rejected' ? '' : 'none'; archiveBox.style.display = ['archived_improved','archived_deceased'].includes(status) ? '' : 'none'; rejectionBox.querySelector('textarea').required = status === 'rejected'; archiveBox.querySelector('textarea').required = ['archived_improved','archived_deceased'].includes(status); }
  assistanceType?.addEventListener('change', toggleMonthlyFields); projectSelect?.addEventListener('change', toggleProjectFields); statusSelect?.addEventListener('change', toggleStatusReason); toggleMonthlyFields(); toggleProjectFields(); toggleStatusReason();

  // Automatic National ID to Birth Date & Age synchronization
  const nidInput = document.getElementById('guardian_national_id');
  if (nidInput) {
    const handleNid = () => {
      if (typeof syncNationalIdToBirthDate === 'function') {
        syncNationalIdToBirthDate(nidInput.value, 'guardian_birth_date', 'guardian_age');
      }
    };
    nidInput.addEventListener('input', handleNid);
    nidInput.addEventListener('change', handleNid);
    nidInput.addEventListener('paste', () => setTimeout(handleNid, 50));
    nidInput.addEventListener('keyup', handleNid);
    if (nidInput.value && nidInput.value.length === 14) {
      handleNid();
    }
  }

  // Initial calculation for patient age if birth date is present
  const pDateEl = document.getElementById('patient_birth_date');
  const pAgeEl = document.getElementById('patient_age');
  if (pDateEl && pDateEl.value && pAgeEl && !pAgeEl.value && typeof calcAge === 'function') {
    calcAge(pDateEl.value, null, 'patient_age');
  } else if (pAgeEl && pAgeEl.value && pDateEl && !pDateEl.value && typeof calcBirthFromAge === 'function') {
    calcBirthFromAge(pAgeEl.value, 'patient_birth_date');
  }
});
</script>
@endsection
